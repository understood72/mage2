<?php
namespace Pfay\Contacts\Controller\Test;
class View extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        die('test view');
    }
}