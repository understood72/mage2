<?php 
namespace Rsg\Enquiry\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class CustomerupdateApi extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        $request = new  \Zend\Soap\Client("http://localhost/magento2/soap/default?wsdl&services=integrationAdminTokenServiceV1");
		$token = $request->integrationAdminTokenServiceV1CreateAdminAccessToken(array("username"=>"admin", "password"=>"admin123"));

		$opts = array(
					'http'=>array(
						'header' => 'Authorization: Bearer '.json_decode($token->result)
					)
				);

		$wsdlUrl = 'http://localhost/magento2sample/soap/default?wsdl&services=serviceName';

		$context = stream_context_create($opts);
		$soapClient = new SoapClient($wsdlUrl, ['version' => SOAP_1_2, 'context' => $context]);

		$soapResponse = $soapClient->__getFunctions();
    }
}

