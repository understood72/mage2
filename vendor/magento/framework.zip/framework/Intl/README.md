# Intl

**Intl** provides an access to Intl extension library wrappers.
