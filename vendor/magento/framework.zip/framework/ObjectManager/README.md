# ObjectManager

**ObjectManager** library is responsible for constructing objects and injecting dependencies based on module di.xml files.