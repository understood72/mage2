<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework\Option;

/**
 * @todo Remove in favor of the ancestor interface
 */
interface ArrayInterface extends \Magento\Framework\Data\OptionSourceInterface
{
}
