A library containing classes to assist with writing tests for Magento 2.
