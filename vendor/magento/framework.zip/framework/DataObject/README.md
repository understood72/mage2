# Object

**Object** library contains functionality for mapping, management and the creation of dynamic member objects.
This also includes the objects which merge, read and make available xml configurations.