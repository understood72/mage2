# Model

**Model** library provides support for MVC models, model context, and storing and retrieving models to the database.