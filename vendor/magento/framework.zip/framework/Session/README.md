#Session

* **SessionManager** Manages active sessions and session metadata.
* **SaveHandler** Supports filesystem and database storage of session data.
* **Config** manages server's session-related configurations.
