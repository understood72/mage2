The Flag library provides a resource model that allows saving permanently a flag (binary indicator), for example, to prevent repetitive actions, if it's not necessary.
