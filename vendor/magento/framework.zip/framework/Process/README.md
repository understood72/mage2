# Process

**Process** provides a factory for Symfony PHP executable finder, which finds the current executable path.
