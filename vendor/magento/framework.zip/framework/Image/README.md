A library for processing images (photos, pictures in digital format). Features:

 * Resizing
 * Watermarking
 * Supports Jpeg, PNG, GIF, BMP, XBM formats and different degrees of opacity
 * Comes with GD (php-gd2) and ImageMagick (php-imagick) adapters out of the box
