<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework;

/**
 * Magento wrapper for Zend's Escaper class
 */
class ZendEscaper extends \Zend\Escaper\Escaper
{
}
