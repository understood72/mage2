A set of utility classes for handling files:

 * Reading/writing data from/to CSV-files
 * Determining mime-type of files based on their extension
 * Calculating file size
 * Sending contents of a file via HTTP (for download)
 * Uploading files
