<?php
/**
 * Integer validator
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Framework\Validator;

class IntUtils extends \Zend_Validate_Int implements \Magento\Framework\Validator\ValidatorInterface
{
}
