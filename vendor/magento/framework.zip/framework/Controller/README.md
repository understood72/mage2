# Controller

**Controller** library is responsible for HTTP response and creating route.

* **Response** * Adapter for Zend Response class. Needed for DI

* **Router** * Route Factory