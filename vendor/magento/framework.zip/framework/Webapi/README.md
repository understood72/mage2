The Webapi library contains functionality for processing web service requests and responses.
