# Overview
CSS library contains common infrastructure to work with style sheets.
It provides an ability to process LESS files in Magento application and convert this dynamic stylesheet language into CSS using correspondent parser.
